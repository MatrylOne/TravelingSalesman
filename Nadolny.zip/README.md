# TravelingSalesman
Trading Salesman genetic algorithm written in Swift

It requires distance and flow matrices that you can download here:
http://anjos.mgi.polymtl.ca/qaplib/inst.html#HRW

author: Jakub Nadolny
