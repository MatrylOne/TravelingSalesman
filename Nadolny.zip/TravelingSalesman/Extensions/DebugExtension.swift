//
//  DebugExtension.swift
//  SILab1
//
//  Created by Jakub Nadolny on 03.03.2018.
//  Copyright © 2018 Jakub Nadolny. All rights reserved.
//

import Foundation

class DebugExtension{
    static let debug = true;
}
