//
//  Math.swift
//  SILab1
//
//  Created by Jakub Nadolny on 25.02.2018.
//  Copyright © 2018 Jakub Nadolny. All rights reserved.
//

import Foundation

class Math{
    class func pow(_ number:Int) -> Int{
        return number*number
    }
}
