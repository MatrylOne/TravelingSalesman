//
//  MatrixFacade.swift
//  SILab1
//
//  Created by Jakub Nadolny on 02.03.2018.
//  Copyright © 2018 Jakub Nadolny. All rights reserved.
//

import Foundation

class MatrixFacade{
    static var calculationData:CalculationData?
}
