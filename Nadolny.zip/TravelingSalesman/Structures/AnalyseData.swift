//
//  AnalyseData.swift
//  TravelingSalesman
//
//  Created by Jakub Nadolny on 15.03.2018.
//  Copyright © 2018 Jakub Nadolny. All rights reserved.
//

import Foundation

struct AnalyseData{
    let worst:Int
    let average:Int
    let best:Int
    
    func getCSV() -> String{
        return "\(worst), \(average), \(best)"
    }
}
