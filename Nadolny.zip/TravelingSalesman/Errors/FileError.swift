//
//  FileError.swift
//  SILab1
//
//  Created by Jakub Nadolny on 24.02.2018.
//  Copyright © 2018 Jakub Nadolny. All rights reserved.
//

import Foundation

enum FileError:Error{
    case RuntimeError(String)
}
